
-- Create enum types
CREATE TYPE public.agent_type AS ENUM ('recon', 'brute', 'sentinel', 'decoy');
CREATE TYPE public.agent_status AS ENUM ('active', 'idle', 'engaged', 'offline');
CREATE TYPE public.threat_severity AS ENUM ('critical', 'high', 'medium', 'low');
CREATE TYPE public.system_state AS ENUM ('operational', 'alert', 'critical');

-- Agents table
CREATE TABLE public.agents (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  type agent_type NOT NULL DEFAULT 'recon',
  status agent_status NOT NULL DEFAULT 'idle',
  target TEXT,
  last_seen TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.agents ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Agents are publicly readable" ON public.agents FOR SELECT USING (true);
CREATE POLICY "Agents can be updated" ON public.agents FOR UPDATE USING (true);

-- Threats table
CREATE TABLE public.threats (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  threat_id TEXT NOT NULL UNIQUE,
  source TEXT NOT NULL,
  severity threat_severity NOT NULL DEFAULT 'low',
  agent_id UUID REFERENCES public.agents(id),
  details TEXT,
  resolved BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.threats ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Threats are publicly readable" ON public.threats FOR SELECT USING (true);
CREATE POLICY "Threats can be created" ON public.threats FOR INSERT WITH CHECK (true);
CREATE POLICY "Threats can be updated" ON public.threats FOR UPDATE USING (true);

-- System status table (single row)
CREATE TABLE public.system_status (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  status system_state NOT NULL DEFAULT 'operational',
  uptime NUMERIC NOT NULL DEFAULT 99.97,
  active_agents INTEGER NOT NULL DEFAULT 0,
  total_threats INTEGER NOT NULL DEFAULT 0,
  resolved_threats INTEGER NOT NULL DEFAULT 0,
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.system_status ENABLE ROW LEVEL SECURITY;
CREATE POLICY "System status is publicly readable" ON public.system_status FOR SELECT USING (true);
CREATE POLICY "System status can be updated" ON public.system_status FOR UPDATE USING (true);

-- Timestamp trigger
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER update_agents_updated_at BEFORE UPDATE ON public.agents FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_threats_updated_at BEFORE UPDATE ON public.threats FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_system_status_updated_at BEFORE UPDATE ON public.system_status FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
