import { motion } from "framer-motion";
import { Shield, Terminal, Loader2 } from "lucide-react";
import StatusOverview from "@/components/StatusOverview";
import AgentGrid from "@/components/AgentGrid";
import ThreatFeed from "@/components/ThreatFeed";
import SwarmVisualizer from "@/components/SwarmVisualizer";
import { useAgents, useThreats, useSystemStatus } from "@/hooks/useHornetData";

export default function Dashboard() {
  const { data: agents, isLoading: agentsLoading } = useAgents();
  const { data: threats, isLoading: threatsLoading } = useThreats();
  const { data: systemStatus, isLoading: statusLoading } = useSystemStatus();

  const isLoading = agentsLoading || threatsLoading || statusLoading;

  return (
    <div className="min-h-screen bg-background hexagon-grid">
      {/* Header */}
      <header className="border-b border-border bg-card/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container flex items-center justify-between h-14 px-4">
          <div className="flex items-center gap-3">
            <Shield size={22} className="text-primary" />
            <div>
              <h1 className="text-sm font-bold font-mono text-gradient leading-none">HORNET DEFENCE</h1>
              <span className="text-[10px] font-mono text-muted-foreground">ShadowMesh Command Center</span>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center gap-1.5 px-2 py-1 rounded bg-secondary text-[10px] font-mono text-muted-foreground">
              <Terminal size={12} />
              <span>v2.1.0</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-success animate-pulse-glow" />
              <span className="text-[10px] font-mono text-success">ONLINE</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container px-4 py-6 space-y-4">
        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 size={32} className="text-primary animate-spin" />
            <span className="ml-3 font-mono text-sm text-muted-foreground">Initializing swarm network...</span>
          </div>
        ) : (
          <>
            {systemStatus && (
              <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
                <StatusOverview status={systemStatus} />
              </motion.div>
            )}

            <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
              <motion.div className="lg:col-span-3" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }}>
                <SwarmVisualizer />
              </motion.div>
              {threats && (
                <motion.div className="lg:col-span-2" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3 }}>
                  <ThreatFeed threats={threats} />
                </motion.div>
              )}
            </div>

            {agents && (
              <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
                <AgentGrid agents={agents} />
              </motion.div>
            )}
          </>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-border py-4 mt-8">
        <div className="container px-4 flex items-center justify-between">
          <span className="text-[10px] font-mono text-muted-foreground">© 2026 Hornet Defence — ShadowMesh Platform</span>
          <span className="text-[10px] font-mono text-muted-foreground">Swarm Intelligence • Bio-Inspired Security</span>
        </div>
      </footer>
    </div>
  );
}
