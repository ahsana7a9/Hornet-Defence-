import { useEffect, useState } from "react";
import { motion } from "framer-motion";

interface SwarmNode {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  type: "agent" | "threat" | "node";
  label: string;
}

interface SwarmLink {
  source: number;
  target: number;
}

function createNodes(): SwarmNode[] {
  const agents: SwarmNode[] = Array.from({ length: 6 }, (_, i) => ({
    id: i,
    x: 150 + Math.random() * 300,
    y: 80 + Math.random() * 200,
    vx: (Math.random() - 0.5) * 0.8,
    vy: (Math.random() - 0.5) * 0.8,
    type: "agent",
    label: `H-${i + 1}`,
  }));
  const threats: SwarmNode[] = Array.from({ length: 3 }, (_, i) => ({
    id: 6 + i,
    x: 100 + Math.random() * 400,
    y: 50 + Math.random() * 260,
    vx: (Math.random() - 0.5) * 0.3,
    vy: (Math.random() - 0.5) * 0.3,
    type: "threat",
    label: `T-${i + 1}`,
  }));
  const networkNodes: SwarmNode[] = Array.from({ length: 4 }, (_, i) => ({
    id: 9 + i,
    x: 80 + Math.random() * 440,
    y: 60 + Math.random() * 240,
    vx: 0,
    vy: 0,
    type: "node",
    label: `N-${i + 1}`,
  }));
  return [...agents, ...threats, ...networkNodes];
}

function createLinks(nodes: SwarmNode[]): SwarmLink[] {
  const links: SwarmLink[] = [];
  const agents = nodes.filter(n => n.type === "agent");
  const threats = nodes.filter(n => n.type === "threat");
  agents.forEach(a => {
    const t = threats[Math.floor(Math.random() * threats.length)];
    if (t) links.push({ source: a.id, target: t.id });
  });
  for (let i = 0; i < agents.length - 1; i++) {
    if (Math.random() > 0.5) links.push({ source: agents[i].id, target: agents[i + 1].id });
  }
  return links;
}

export default function SwarmVisualizer() {
  const [nodes, setNodes] = useState<SwarmNode[]>(createNodes);
  const [links] = useState<SwarmLink[]>(() => createLinks(nodes));

  useEffect(() => {
    const interval = setInterval(() => {
      setNodes(prev =>
        prev.map(n => {
          if (n.type === "node") return n;
          let nx = n.x + n.vx;
          let ny = n.y + n.vy;
          let nvx = n.vx;
          let nvy = n.vy;
          if (nx < 20 || nx > 580) nvx *= -1;
          if (ny < 20 || ny > 340) nvy *= -1;
          nx = Math.max(20, Math.min(580, nx));
          ny = Math.max(20, Math.min(340, ny));
          if (Math.random() > 0.95) {
            nvx += (Math.random() - 0.5) * 0.5;
            nvy += (Math.random() - 0.5) * 0.5;
          }
          return { ...n, x: nx, y: ny, vx: nvx, vy: nvy };
        })
      );
    }, 50);
    return () => clearInterval(interval);
  }, []);

  const nodeById = (id: number) => nodes.find(n => n.id === id);

  const nodeColor = (type: string) => {
    if (type === "agent") return "hsl(45, 100%, 55%)";
    if (type === "threat") return "hsl(0, 72%, 51%)";
    return "hsl(215, 12%, 50%)";
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="rounded-lg border border-border bg-card p-4"
    >
      <h2 className="text-sm font-mono uppercase tracking-wider text-foreground mb-3 flex items-center gap-2">
        <span className="w-2 h-2 rounded-full bg-primary animate-pulse-glow" />
        Swarm Network
      </h2>
      <svg viewBox="0 0 600 360" className="w-full h-auto" style={{ maxHeight: 320 }}>
        <defs>
          <filter id="glow">
            <feGaussianBlur stdDeviation="3" result="blur" />
            <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
          </filter>
        </defs>
        {links.map((l, i) => {
          const s = nodeById(l.source);
          const t = nodeById(l.target);
          if (!s || !t) return null;
          return (
            <line
              key={i}
              x1={s.x} y1={s.y} x2={t.x} y2={t.y}
              stroke="hsl(45, 100%, 55%)"
              strokeOpacity={0.15}
              strokeWidth={1}
            />
          );
        })}
        {nodes.map(n => (
          <g key={n.id}>
            <circle cx={n.x} cy={n.y} r={n.type === "threat" ? 8 : n.type === "agent" ? 6 : 4}
              fill={nodeColor(n.type)} opacity={0.9} filter="url(#glow)" />
            <text x={n.x} y={n.y - 12} textAnchor="middle" fill="hsl(180, 10%, 70%)"
              fontSize={9} fontFamily="JetBrains Mono, monospace">{n.label}</text>
          </g>
        ))}
      </svg>
      <div className="flex items-center gap-4 mt-2 justify-center">
        {[["Agent", "hsl(45,100%,55%)"], ["Threat", "hsl(0,72%,51%)"], ["Node", "hsl(215,12%,50%)"]].map(([label, color]) => (
          <div key={label} className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full" style={{ background: color }} />
            <span className="text-[10px] font-mono text-muted-foreground">{label}</span>
          </div>
        ))}
      </div>
    </motion.div>
  );
}
