import { motion, AnimatePresence } from "framer-motion";
import { Wifi, WifiOff, Crosshair, Eye, ShieldAlert, Ghost } from "lucide-react";
import type { Agent } from "@/hooks/useHornetData";

const typeIcons: Record<Agent["type"], React.ReactNode> = {
  recon: <Eye size={14} />,
  brute: <Crosshair size={14} />,
  sentinel: <ShieldAlert size={14} />,
  decoy: <Ghost size={14} />,
};

const statusColors: Record<Agent["status"], string> = {
  active: "bg-success",
  engaged: "bg-warning",
  idle: "bg-muted-foreground",
  offline: "bg-destructive",
};

export default function AgentGrid({ agents }: { agents: Agent[] }) {
  return (
    <div className="rounded-lg border border-border bg-card p-4">
      <div className="flex items-center gap-2 mb-4">
        <Wifi size={16} className="text-primary" />
        <h2 className="text-sm font-mono uppercase tracking-wider text-foreground">Swarm Agents</h2>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
        <AnimatePresence>
          {agents.map((agent) => (
            <motion.div
              key={agent.id}
              layout
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="rounded-md border border-border bg-secondary/50 p-3"
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="text-primary">{typeIcons[agent.type]}</span>
                  <span className="text-xs font-mono font-semibold text-foreground">{agent.name}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className={`w-2 h-2 rounded-full ${statusColors[agent.status]} ${agent.status === "engaged" ? "animate-pulse-glow" : ""}`} />
                  <span className="text-[10px] font-mono uppercase text-muted-foreground">{agent.status}</span>
                </div>
              </div>
              {agent.target && (
                <div className="text-[10px] font-mono text-accent truncate">
                  → {agent.target}
                </div>
              )}
              <div className="text-[10px] font-mono text-muted-foreground mt-1">
                {agent.status === "offline" ? <WifiOff size={10} className="inline mr-1" /> : null}
                Type: {agent.type}
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}
