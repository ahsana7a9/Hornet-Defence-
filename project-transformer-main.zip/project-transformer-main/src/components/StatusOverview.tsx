import { motion } from "framer-motion";
import { Shield, Activity, Bug, AlertTriangle } from "lucide-react";
import type { SystemStatus } from "@/hooks/useHornetData";

interface StatusCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  trend?: string;
  variant?: "default" | "success" | "warning" | "danger";
}

function StatusCard({ title, value, icon, trend, variant = "default" }: StatusCardProps) {
  const variantClasses = {
    default: "border-border",
    success: "border-success/30",
    warning: "border-warning/30",
    danger: "border-threat-critical/30 glow-threat",
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={`rounded-lg border bg-card p-4 ${variantClasses[variant]}`}
    >
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs font-mono uppercase tracking-wider text-muted-foreground">{title}</span>
        <span className="text-primary">{icon}</span>
      </div>
      <div className="text-2xl font-bold font-mono text-foreground">{value}</div>
      {trend && <span className="text-xs text-muted-foreground mt-1 block">{trend}</span>}
    </motion.div>
  );
}

export default function StatusOverview({ status }: { status: SystemStatus }) {
  const statusVariant = status.status === "critical" ? "danger" : status.status === "alert" ? "warning" : "success";
  
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
      <StatusCard
        title="System Status"
        value={status.status.toUpperCase()}
        icon={<Shield size={18} />}
        trend={`Uptime: ${status.uptime}%`}
        variant={statusVariant}
      />
      <StatusCard
        title="Active Agents"
        value={status.activeAgents}
        icon={<Activity size={18} />}
        trend="of 6 deployed"
        variant="success"
      />
      <StatusCard
        title="Total Threats"
        value={status.totalThreats}
        icon={<Bug size={18} />}
        trend="last 24h"
        variant="warning"
      />
      <StatusCard
        title="Unresolved"
        value={status.totalThreats - status.resolvedThreats}
        icon={<AlertTriangle size={18} />}
        trend={`${status.resolvedThreats} resolved`}
        variant={status.totalThreats - status.resolvedThreats > 5 ? "danger" : "default"}
      />
    </div>
  );
}
