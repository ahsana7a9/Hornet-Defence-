import { motion, AnimatePresence } from "framer-motion";
import { AlertTriangle, CheckCircle } from "lucide-react";
import type { ThreatEvent } from "@/hooks/useHornetData";

const severityStyles: Record<ThreatEvent["severity"], string> = {
  critical: "border-l-threat-critical text-threat-critical",
  high: "border-l-threat-high text-threat-high",
  medium: "border-l-threat-medium text-threat-medium",
  low: "border-l-threat-low text-threat-low",
};

function timeAgo(ts: string) {
  const s = Math.floor((Date.now() - new Date(ts).getTime()) / 1000);
  if (s < 60) return `${s}s ago`;
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  return `${Math.floor(s / 86400)}d ago`;
}

export default function ThreatFeed({ threats }: { threats: ThreatEvent[] }) {
  return (
    <div className="rounded-lg border border-border bg-card p-4 max-h-[420px] overflow-hidden flex flex-col">
      <div className="flex items-center gap-2 mb-4">
        <AlertTriangle size={16} className="text-warning" />
        <h2 className="text-sm font-mono uppercase tracking-wider text-foreground">Threat Feed</h2>
        <span className="ml-auto text-[10px] font-mono text-muted-foreground">LIVE</span>
        <span className="w-2 h-2 rounded-full bg-destructive animate-pulse-glow" />
      </div>
      <div className="overflow-y-auto space-y-1.5 flex-1 pr-1">
        <AnimatePresence initial={false}>
          {threats.slice(0, 15).map((threat) => (
            <motion.div
              key={threat.id}
              initial={{ opacity: 0, x: -20, height: 0 }}
              animate={{ opacity: 1, x: 0, height: "auto" }}
              exit={{ opacity: 0, x: 20 }}
              transition={{ duration: 0.3 }}
              className={`rounded-md border-l-2 bg-secondary/30 px-3 py-2 ${severityStyles[threat.severity]}`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono font-bold">{threat.threatId}</span>
                  <span className="text-[10px] font-mono uppercase px-1.5 py-0.5 rounded bg-secondary">
                    {threat.severity}
                  </span>
                </div>
                <div className="flex items-center gap-1.5">
                  {threat.resolved && <CheckCircle size={12} className="text-success" />}
                  <span className="text-[10px] font-mono text-muted-foreground">{timeAgo(threat.timestamp)}</span>
                </div>
              </div>
              <p className="text-[11px] font-mono text-muted-foreground mt-1 truncate">{threat.details}</p>
              <div className="text-[10px] font-mono text-accent mt-0.5">src: {threat.source}</div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}
