import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

type AgentRow = Database["public"]["Tables"]["agents"]["Row"];
type ThreatRow = Database["public"]["Tables"]["threats"]["Row"];
type SystemStatusRow = Database["public"]["Tables"]["system_status"]["Row"];

export interface Agent {
  id: string;
  name: string;
  type: AgentRow["type"];
  status: AgentRow["status"];
  target?: string | null;
  lastSeen: string;
}

export interface ThreatEvent {
  id: string;
  threatId: string;
  source: string;
  severity: ThreatRow["severity"];
  timestamp: string;
  agentId: string | null;
  details: string | null;
  resolved: boolean;
}

export interface SystemStatus {
  status: SystemStatusRow["status"];
  uptime: number;
  activeAgents: number;
  totalThreats: number;
  resolvedThreats: number;
}

function mapAgent(row: AgentRow): Agent {
  return {
    id: row.id,
    name: row.name,
    type: row.type,
    status: row.status,
    target: row.target,
    lastSeen: row.last_seen,
  };
}

function mapThreat(row: ThreatRow): ThreatEvent {
  return {
    id: row.id,
    threatId: row.threat_id,
    source: row.source,
    severity: row.severity,
    timestamp: row.created_at,
    agentId: row.agent_id,
    details: row.details,
    resolved: row.resolved,
  };
}

function mapSystemStatus(row: SystemStatusRow): SystemStatus {
  return {
    status: row.status,
    uptime: row.uptime,
    activeAgents: row.active_agents,
    totalThreats: row.total_threats,
    resolvedThreats: row.resolved_threats,
  };
}

export function useAgents() {
  return useQuery({
    queryKey: ["agents"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("agents")
        .select("*")
        .order("name");
      if (error) throw error;
      return (data || []).map(mapAgent);
    },
    refetchInterval: 5000,
  });
}

export function useThreats() {
  return useQuery({
    queryKey: ["threats"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("threats")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data || []).map(mapThreat);
    },
    refetchInterval: 5000,
  });
}

export function useSystemStatus() {
  return useQuery({
    queryKey: ["system_status"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("system_status")
        .select("*")
        .limit(1)
        .single();
      if (error) throw error;
      return mapSystemStatus(data);
    },
    refetchInterval: 5000,
  });
}
